package br.com.LojaDePesca.ctr;

import br.com.LojaDePesca.dao.PrincipalDAO;
import br.com.LojaDePesca.dto.PrincipalDTO;
import java.sql.ResultSet;

public class PrincipalCTR {
    PrincipalDAO dao = new PrincipalDAO();
    public boolean cadastrar(PrincipalDTO dto){
        return dao.cadastrar(dto);
    }
    
      public boolean login(PrincipalDTO dto){
        return dao.login(dto);
    }
      
      public boolean addCarrinho(PrincipalDTO dto){
          return dao.addCarrinho(dto);
      }
      
      public ResultSet getCarrinho(PrincipalDTO dto){
            return dao.getCarrinhoByEmail(dto.getEmail());
      }         
      
      public boolean excluir(PrincipalDTO dto){
          return dao.excluir(dto.getItem());
      }
 }
