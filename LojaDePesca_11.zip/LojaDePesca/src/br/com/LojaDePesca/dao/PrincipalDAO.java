
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.LojaDePesca.dao;

import br.com.LojaDePesca.dto.PrincipalDTO;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Latitude 3490
 */
public class PrincipalDAO {
    
   public boolean addCarrinho(PrincipalDTO dto) {
    try {
        ConexaoDAO.ConnectDB();
        
        // Verifica se o produto já existe no carrinho
        String checkSql = "SELECT quantidade, valorTotal FROM carrinho WHERE email_user = ? AND tipo = ?";
        PreparedStatement checkStmt = ConexaoDAO.conn.prepareStatement(checkSql);
        checkStmt.setString(1, dto.getEmail());
        checkStmt.setString(2, dto.getItem());
        
        ResultSet rs = checkStmt.executeQuery();
        
        if (rs.next()) {
            // Produto já existe, faz o update somando as quantidades e atualizando o preço
            int quantidadeExistente = rs.getInt("quantidade");
            float valorTotalExistente = rs.getFloat("valorTotal");
            
            String updateSql = "UPDATE carrinho SET quantidade = ?, valorTotal = ? WHERE email_user = ? AND tipo = ?";
            PreparedStatement updateStmt = ConexaoDAO.conn.prepareStatement(updateSql);
            
            int novaQuantidade = quantidadeExistente + dto.getQuantidade();
            float novoValorTotal = valorTotalExistente + (dto.getQuantidade() * dto.getPreco());
            
            updateStmt.setInt(1, novaQuantidade);
            updateStmt.setFloat(2, novoValorTotal);
            updateStmt.setString(3, dto.getEmail());
            updateStmt.setString(4, dto.getItem());
            
            updateStmt.executeUpdate();
        } else {
            // Produto não existe, faz o insert
            String insertSql = "INSERT INTO carrinho (quantidade, valorTotal, email_user, tipo) VALUES (?, ?, ?, ?)";
            PreparedStatement insertStmt = ConexaoDAO.conn.prepareStatement(insertSql);
            
            insertStmt.setInt(1, dto.getQuantidade());
            insertStmt.setFloat(2, dto.getQuantidade() * dto.getPreco());
            insertStmt.setString(3, dto.getEmail());
            insertStmt.setString(4, dto.getItem());
            
            insertStmt.executeUpdate();
        }
        
        ConexaoDAO.conn.commit();
        return true;
    } catch (Exception e) {
        System.out.println("Erro: " + e.getMessage());
        return false;
    }
}

    
    public boolean cadastrar(PrincipalDTO dto) {
        ConexaoDAO.ConnectDB();
        try{
            PreparedStatement pstmt =ConexaoDAO.conn.prepareStatement("INSERT INTO cliente(nome, cpf, cidade, email, senha) VALUES (?, ?, ?, ?, ?)");
            pstmt.setString(1, dto.getNome());
            pstmt.setString(2, dto.getCpf());
            pstmt.setString(3, dto.getCidade());
            pstmt.setString(4, dto.getEmail());
            pstmt.setString(5, dto.getSenha());
            
            pstmt.executeUpdate();
            ConexaoDAO.conn.commit();
            return true;
        } catch(Exception e ){
            System.out.println("Erro: " + e.getMessage());
            return false;
        }finally{
            ConexaoDAO.CloseDB();
        }
        
    }
    
    
     
      public boolean login(PrincipalDTO dto){
           try{
            ConexaoDAO.ConnectDB();
           
            String sql = "SELECT * FROM "
                    + " cliente " 
                    + " WHERE email = '"
                    + dto.getEmail()
                    + "' AND  senha  = '"
                    + dto.getSenha()
           +"'" ;
            
            System.out.println(sql);
            PreparedStatement pstmt = ConexaoDAO.conn.prepareStatement(sql);
            
            
                   
        ResultSet rs = pstmt.executeQuery();
        ConexaoDAO.conn.commit();
        
        if(rs.next()) return true;
        
        } catch(Exception e){
            System.out.println(e);
            return false;
        }
           return false;
    }
      
      public ResultSet getCarrinhoByEmail(String email) {
    ResultSet rs = null;
    try {
        ConexaoDAO.ConnectDB();
        
        String sql = "SELECT quantidade, valorTotal, tipo FROM carrinho WHERE email_user = ?";
        PreparedStatement pstmt = ConexaoDAO.conn.prepareStatement(sql);
        pstmt.setString(1, email);
        
        rs = pstmt.executeQuery();
        return rs;
        
    } catch (Exception e) {
        System.out.println("Erro: " + e.getMessage());
    }
    return null;
      }
    
public boolean excluir(String tipo) {
    ResultSet rs = null;
    try {
        ConexaoDAO.ConnectDB();
        
        String sql = "DELETE FROM carrinho WHERE tipo = ?";
        PreparedStatement pstmt = ConexaoDAO.conn.prepareStatement(sql);
        pstmt.setString(1, tipo);
        
        pstmt.executeUpdate();
        ConexaoDAO.conn.commit();
        return true;
    } catch (Exception e) {
        System.out.println("Erro: " + e.getMessage());
    }
    return false;
}

    
}
