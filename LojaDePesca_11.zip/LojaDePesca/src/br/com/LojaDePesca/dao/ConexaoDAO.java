package br.com.LojaDePesca.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexaoDAO {
    
    public static Connection conn = null;
    
    public static void ConnectDB() {
        try {
            String dsn = "pesca"; 
            String user = "root"; 
            String senha = "";  
            String porta = "3306";
            
            String url = "jdbc:mysql://localhost:" + porta + "/" + dsn;

            // Conexão automática sem registrar driver explicitamente
            conn = DriverManager.getConnection(url, user, senha);

            conn.setAutoCommit(false);

            System.out.println("Conexão com o banco de dados MySQL estabelecida com sucesso.");
        } catch (SQLException e) {
            System.out.println("Problema ao abrir a base de dados: " + e.getMessage());
        }
    }

    public static void CloseDB() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
                System.out.println("Conexão com o banco de dados encerrada com sucesso.");
            }
        } catch (Exception e) {
            System.out.println("Problema ao fechar a base de dados: " + e.getMessage());
        }           
    }  
}